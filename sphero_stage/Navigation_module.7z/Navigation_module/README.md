# Navigation module details


read_map.py: Is the node to see the true map. (You can extract the code and use as well as you prefer)
round_boundary.py : optional, just to visualize the circle around the robot in RViz
simulation_tf_modified.py : To publish the transformation for RVIz visualization.
utils.py : Vector class (can be used for position or velocity vectors for each or all the robots)
boid.py : class to be assigned for each robot.
working_1_robot_perfect_class.py : main file that handles everything.

To run this setup:

1. roscore
2. rosrun sphero_stage start.py
3. rosrun sphero_stage work_1_robot_perfect_class.py